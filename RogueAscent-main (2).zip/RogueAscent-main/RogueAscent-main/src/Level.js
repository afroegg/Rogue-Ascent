class Level {
    constructor(jsonData) {
        this.id = jsonData.id || "unknown";
        this.name = jsonData.name || "Unnamed Level";
        this.description = jsonData.description || "";
        this.tileSize = jsonData.tileSize || 16;
        this.layers = jsonData.layers || [];
        this.spriteSheets = jsonData.spriteSheets || {};
        
        // Level elements
        this.platforms = []; // Solid tiles for collision
        this.hazards = []; // Hazardous tiles that damage the player
        this.checkpoints = jsonData.checkpoints || [];
        this.spawn = jsonData.spawn || { x: 0, y: 0 };
        this.exit = jsonData.exit || null;
        
        // Background image
        this.backgroundImage = null;
        this.loadBackgroundImage(jsonData.id);
        
        // Parse level elements
        this.parseElements();
    }
    
    loadBackgroundImage(levelId) {
        // Try to load the corresponding background image for this level
        if (levelId) {
            const img = new Image();
            
            // Extract level name from ID and format it properly
            const levelName = levelId.split('_').map(word => 
                word.charAt(0).toUpperCase() + word.slice(1)
            ).join('_');
            
            // Try both PNG and WebP formats with proper casing
            const possiblePaths = [
                `Level/test/Tutorial_Project/${levelName}.png`,
                `Level/test/Tutorial_Project/${levelName}.webp`,
                // Try alternate casing
                `Level/test/Tutorial_Project/${levelId}.png`,
                `Level/test/Tutorial_Project/${levelId}.webp`,
                // Fallback to Tutorial.png
                `Level/test/Tutorial_Project/Tutorial.png`
            ];
            
            console.log(`Trying to load image for level: ${levelId}`);
            console.log(`Possible paths:`, possiblePaths);
            
            // Use the first path that loads successfully
            let pathIndex = 0;
            
            const tryLoadImage = () => {
                if (pathIndex >= possiblePaths.length) {
                    console.warn(`Could not load background image for level: ${levelId}`);
                    // Use a solid color as fallback
                    this.backgroundImage = null;
                    return;
                }
                
                console.log(`Trying path: ${possiblePaths[pathIndex]}`);
                img.src = possiblePaths[pathIndex];
                
                img.onerror = () => {
                    console.error(`Failed to load image from: ${possiblePaths[pathIndex]}`);
                    pathIndex++;
                    tryLoadImage();
                };
            };
            
            img.onload = () => {
                console.log(`Successfully loaded background image: ${img.src}`);
                this.backgroundImage = img;
            };
            
            tryLoadImage();
        }
    }
    
    parseElements() {
        // Parse platforms and other elements from layers
        for (const layer of this.layers) {
            if (!layer.tiles || !Array.isArray(layer.tiles)) continue;
            
            // Check layer type by name
            const layerName = layer.name ? layer.name.toLowerCase() : "";
            
            if (layerName.includes("platform")) {
                this.parsePlatforms(layer);
            } else if (layerName.includes("hazard")) {
                this.parseHazards(layer);
            }
        }
    }
    
    parsePlatforms(layer) {
        for (const tile of layer.tiles) {
            this.platforms.push({
                id: tile.id || "platform",
                x: tile.x * this.tileSize,
                y: tile.y * this.tileSize,
                width: (tile.width || 1) * this.tileSize,
                height: (tile.height || 1) * this.tileSize
            });
        }
    }
    
    parseHazards(layer) {
        for (const tile of layer.tiles) {
            this.hazards.push({
                id: tile.id || "hazard",
                x: tile.x * this.tileSize,
                y: tile.y * this.tileSize,
                width: (tile.width || 1) * this.tileSize,
                height: (tile.height || 1) * this.tileSize
            });
        }
    }
    
    // Check if player is colliding with any platform
    checkPlatformCollision(player, phaseThrough = false) {
        let isGrounded = false;
        let wasCollision = false;
        
        for (const platform of this.platforms) {
            // Skip collision check if phasing through
            if (phaseThrough) continue;
            
            // Calculate collision bounds with improved precision
            const overlapX = player.x + player.width > platform.x && player.x < platform.x + platform.width;
            const overlapY = player.y + player.height > platform.y && player.y < platform.y + platform.height;
            const wasAbovePlatform = player.y + player.height - player.velocityY <= platform.y + 2;
            
            if (overlapX && overlapY) {
                // Top collision (landing)
                if (wasAbovePlatform && player.velocityY >= 0) {
                    player.y = platform.y - player.height;
                    player.velocityY = 0;
                    isGrounded = true;
                    wasCollision = true;
                }
                // Bottom collision (hitting head)
                else if (player.velocityY < 0 && !wasAbovePlatform) {
                    player.y = platform.y + platform.height;
                    player.velocityY = 0;
                    wasCollision = true;
                }
                // Side collisions
                else if (!isGrounded) {
                    // Left collision
                    if (player.velocityX > 0 && player.x + player.width - player.velocityX <= platform.x + 2) {
                        player.x = platform.x - player.width;
                        wasCollision = true;
                    }
                    // Right collision
                    else if (player.velocityX < 0 && player.x - player.velocityX >= platform.x + platform.width - 2) {
                        player.x = platform.x + platform.width;
                        wasCollision = true;
                    }
                }
            }
        }
        
        // Update player state based on collisions
        if (wasCollision) {
            // Reset air combo if grounded
            if (isGrounded) {
                player.airComboCount = 0;
                player.airComboTimer = 0;
            }
            
            // Cancel dashing on collision
            if (player.dashing) {
                player.dashing = false;
                player.dashTimer = 0;
                player.dashCooldown = player.dashCooldownTime;
            }
            
            // Cancel lunging stab on collision
            if (player.lungingStab) {
                player.lungingStab = false;
                player.lungingStabTimer = 0;
                player.lungingStabCooldown = player.lungingStabCooldownTime;
            }
        }
        
        return isGrounded;
    }
    
    // Check if player is colliding with any hazard
    checkHazardCollision(player) {
        for (const hazard of this.hazards) {
            if (player.x + player.width > hazard.x &&
                player.x < hazard.x + hazard.width &&
                player.y + player.height > hazard.y &&
                player.y < hazard.y + hazard.height) 
            {
                return true; // Collision detected
            }
        }
        return false;
    }
    
    // Check if player has reached the exit
    checkExitReached(player) {
        if (!this.exit) return false;
        
        const exitX = this.exit.x * this.tileSize;
        const exitY = this.exit.y * this.tileSize;
        const exitWidth = this.tileSize;
        const exitHeight = this.tileSize;
        
        return (player.x + player.width > exitX &&
                player.x < exitX + exitWidth &&
                player.y + player.height > exitY &&
                player.y < exitY + exitHeight);
    }
    
    // Check if player has reached a checkpoint
    checkCheckpointReached(player) {
        for (let i = 0; i < this.checkpoints.length; i++) {
            const checkpoint = this.checkpoints[i];
            const checkpointX = checkpoint.x * this.tileSize;
            const checkpointY = checkpoint.y * this.tileSize;
            const checkpointWidth = this.tileSize;
            const checkpointHeight = this.tileSize;
            
            if (player.x + player.width > checkpointX &&
                player.x < checkpointX + checkpointWidth &&
                player.y + player.height > checkpointY &&
                player.y < checkpointY + checkpointHeight) 
            {
                return i; // Return checkpoint index
            }
        }
        return -1; // No checkpoint reached
    }
    
    draw(ctx, cameraX = 0, cameraY = 0, currentCheckpoint = -1) {
        // Calculate level dimensions based on platforms
        const levelWidth = Math.max(...this.platforms.map(p => p.x + p.width), canvas.width * 2);
        const levelHeight = Math.max(...this.platforms.map(p => p.y + p.height), canvas.height);
        
        // Draw solid background color as fallback
        ctx.fillStyle = "#1a1a2e";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw background image if available
        if (this.backgroundImage && this.backgroundImage.complete) {
            try {
                // Draw the background with parallax effect (slower scrolling)
                const parallaxFactor = 0.5;
                const bgX = -cameraX * parallaxFactor;
                
                // Option 1: Stretch background to fit level
                ctx.drawImage(this.backgroundImage, bgX, 0, levelWidth, levelHeight);
            } catch (e) {
                console.error("Error drawing background:", e);
            }
        }
        
        // Draw platforms with improved visual style
        for (const platform of this.platforms) {
            const x = Math.floor(platform.x - cameraX);
            const y = Math.floor(platform.y - cameraY);
            
            // Platform gradient fill
            const gradient = ctx.createLinearGradient(x, y, x, y + platform.height);
            gradient.addColorStop(0, "rgba(100, 100, 100, 0.8)");
            gradient.addColorStop(1, "rgba(70, 70, 70, 0.8)");
            ctx.fillStyle = gradient;
            
            // Draw platform with rounded corners
            ctx.beginPath();
            ctx.roundRect(x, y, platform.width, platform.height, 2);
            ctx.fill();
            
            // Platform border
            ctx.strokeStyle = "rgba(40, 40, 40, 0.9)";
            ctx.lineWidth = 2;
            ctx.stroke();
        }
        
        // Draw hazards with glowing effect
        for (const hazard of this.hazards) {
            const x = Math.floor(hazard.x - cameraX);
            const y = Math.floor(hazard.y - cameraY);
            
            // Hazard glow
            ctx.shadowColor = "rgba(255, 0, 0, 0.5)";
            ctx.shadowBlur = 10;
            
            // Hazard gradient
            const gradient = ctx.createLinearGradient(x, y, x, y + hazard.height);
            gradient.addColorStop(0, "rgba(255, 60, 60, 0.8)");
            gradient.addColorStop(1, "rgba(200, 30, 30, 0.8)");
            ctx.fillStyle = gradient;
            
            // Draw hazard
            ctx.fillRect(x, y, hazard.width, hazard.height);
            
            // Reset shadow
            ctx.shadowBlur = 0;
            
            // Hazard pattern
            ctx.strokeStyle = "rgba(255, 255, 255, 0.3)";
            ctx.lineWidth = 2;
            ctx.beginPath();
            for (let i = 0; i < hazard.width + hazard.height; i += 10) {
                ctx.moveTo(x + Math.min(i, hazard.width), y + Math.max(0, i - hazard.width));
                ctx.lineTo(x + Math.max(0, i - hazard.height), y + Math.min(i, hazard.height));
            }
            ctx.stroke();
        }
        
        // Draw checkpoints with animation
        this.checkpoints.forEach((checkpoint, index) => {
            const x = Math.floor(checkpoint.x * this.tileSize - cameraX);
            const y = Math.floor(checkpoint.y * this.tileSize - cameraY);
            const size = this.tileSize;
            
            // Checkpoint base
            ctx.fillStyle = index <= currentCheckpoint ? "rgba(60, 255, 60, 0.8)" : "rgba(180, 180, 180, 0.6)";
            ctx.strokeStyle = index <= currentCheckpoint ? "#2ECC71" : "#95A5A6";
            ctx.lineWidth = 2;
            
            // Draw checkpoint platform
            ctx.beginPath();
            ctx.roundRect(x, y, size, size, 4);
            ctx.fill();
            ctx.stroke();
            
            // Checkpoint flag
            const flagHeight = size * 0.7;
            const poleX = x + size * 0.3;
            
            // Flag pole
            ctx.fillStyle = "#34495E";
            ctx.fillRect(poleX, y + size * 0.15, size * 0.1, flagHeight);
            
            // Flag
            ctx.fillStyle = index <= currentCheckpoint ? "#2ECC71" : "#95A5A6";
            ctx.beginPath();
            ctx.moveTo(poleX + size * 0.1, y + size * 0.2);
            ctx.lineTo(poleX + size * 0.6, y + size * 0.35);
            ctx.lineTo(poleX + size * 0.1, y + size * 0.5);
            ctx.closePath();
            ctx.fill();
            
            // Add glow effect for active checkpoint
            if (index === currentCheckpoint) {
                ctx.shadowColor = "rgba(46, 204, 113, 0.5)";
                ctx.shadowBlur = 15;
                ctx.strokeStyle = "#2ECC71";
                ctx.lineWidth = 3;
                ctx.stroke();
                ctx.shadowBlur = 0;
            }
        });
        
        // Draw exit with animation
        if (this.exit) {
            const x = Math.floor(this.exit.x * this.tileSize - cameraX);
            const y = Math.floor(this.exit.y * this.tileSize - cameraY);
            const size = this.tileSize;
            
            // Exit portal effect
            ctx.save();
            ctx.globalAlpha = 0.8 + Math.sin(Date.now() / 500) * 0.2;
            
            // Portal gradient
            const gradient = ctx.createRadialGradient(
                x + size/2, y + size/2, 0,
                x + size/2, y + size/2, size
            );
            gradient.addColorStop(0, "rgba(100, 100, 255, 0.9)");
            gradient.addColorStop(1, "rgba(50, 50, 200, 0.3)");
            
            // Draw portal
            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.arc(x + size/2, y + size/2, size/2, 0, Math.PI * 2);
            ctx.fill();
            
            // Portal ring
            ctx.strokeStyle = "#4444FF";
            ctx.lineWidth = 3;
            ctx.stroke();
            
            // Inner glow
            ctx.shadowColor = "#6666FF";
            ctx.shadowBlur = 15;
            ctx.beginPath();
            ctx.arc(x + size/2, y + size/2, size/3, 0, Math.PI * 2);
            ctx.stroke();
            
            ctx.restore();
        }
    }
}
